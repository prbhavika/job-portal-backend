# Job Portal Backend API

A backend-only job portal built with Node.js, Express, MongoDB, and Mongoose. It supports Job Seeker, Employer, and Admin roles, JWT authentication in an httpOnly cookie, profile management, job listings, applications, and protected admin operations.

## Requirements

- Node.js 18 or later
- npm
- MongoDB Community Server running locally, or a free MongoDB Atlas cluster
- Postman

## Setup

1. Extract the ZIP and open the project folder in a terminal.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Set `MONGODB_URI` and replace `JWT_SECRET` with a long random value.
5. Start MongoDB if you are using a local database.
6. Start the API:

   ```bash
   npm run dev
   ```

7. Confirm the service at `http://localhost:5000/api/health`.

No paid service is required. MongoDB can run locally or with the free Atlas tier.

## Authentication and roles

Registration accepts `jobseeker` or `employer`. Public registration does not allow creation of an Admin account. To create the first administrator, register an account, then use `mongosh` against the configured database:

```javascript
db.users.updateOne(
  { email: "admin@example.com" },
  { $set: { role: "admin" } }
)
```

Use the email you registered. Log in again after changing the role. The login response sets the `token` httpOnly cookie. Postman can retain and send cookies automatically for `localhost`.

## Main routes

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Register Job Seeker or Employer |
| POST | `/api/auth/login` | Public | Login and set cookie |
| POST | `/api/auth/logout` | Public | Clear cookie |
| GET | `/api/auth/me` | Authenticated | Current account |
| GET | `/api/users/profile` | Authenticated | Read own profile |
| PATCH | `/api/users/profile` | Authenticated | Update own profile |
| GET | `/api/jobs` | Public | Browse open jobs |
| GET | `/api/jobs/:id` | Public | Read a job |
| GET | `/api/jobs/mine` | Employer | List own jobs |
| POST | `/api/jobs` | Employer | Create a job |
| PATCH | `/api/jobs/:id` | Owning Employer | Update a job |
| DELETE | `/api/jobs/:id` | Owning Employer | Delete a job and its applications |
| POST | `/api/applications` | Job Seeker | Apply for a job |
| GET | `/api/applications/mine` | Job Seeker | View own applications and statuses |
| GET | `/api/applications/received` | Employer | View applications for own jobs |
| PATCH | `/api/applications/:id/status` | Owning Employer | Update an application status |
| GET | `/api/admin/users` | Admin | List users |
| GET | `/api/admin/users/:id` | Admin | Read a user |
| PATCH | `/api/admin/users/:id/status` | Admin | Block or activate a user |
| DELETE | `/api/admin/users/:id` | Admin | Delete a user and associated records |
| GET | `/api/admin/jobs` | Admin | List all jobs |
| GET | `/api/admin/jobs/:id` | Admin | Read a job |
| DELETE | `/api/admin/jobs/:id` | Admin | Remove a job |
| GET | `/api/admin/overview` | Admin | Platform counts |

Job listing supports `search`, `location`, `employmentType`, `page`, and `limit` query parameters.

## Database design

- `User` stores authentication, role, profile, skills, and embedded education details.
- `Job` references the Employer in `employer`.
- `Application` references both `Job` and Job Seeker. A unique compound index prevents duplicate applications for the same job.
- Passwords are hashed using bcrypt before storage and are excluded from normal query results and JSON responses.

## Postman

Import `postman/Job-Portal-Backend.postman_collection.json` into Postman. The collection includes public requests, role-based flows, validation cases, authorization checks, and cookie-based authentication.

Run requests in this order for a full manual flow:

1. Health Check
2. Register Job Seeker
3. Register Employer
4. Login as Employer
5. Create Job
6. Login as Job Seeker
7. Browse Jobs
8. Apply to Job
9. View My Applications
10. Login as Employer
11. View Received Applications
12. Update Application Status

The collection stores returned IDs in collection variables. Register a separate Admin account and promote it in MongoDB before running Admin requests. Admin registration is intentionally not exposed publicly.

## Security notes

- Keep `.env` out of version control.
- Use HTTPS and `NODE_ENV=production` in production.
- The default local CORS origin is `http://localhost:3000`; update `CLIENT_ORIGIN` if needed.
- For cross-site production deployments, configure secure cookies and CORS to match the deployment domains.
- This is a learning project. Review deployment security and operational requirements before production use.
