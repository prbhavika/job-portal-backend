const jwt = require("jsonwebtoken");

function createToken(userId) {
  if (!process.env.JWT_SECRET) {
    throw new Error("JWT_SECRET is required");
  }
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "1d"
  });
}

function cookieOptions() {
  const production = process.env.NODE_ENV === "production";
  return {
    httpOnly: true,
    secure: production,
    sameSite: production ? "none" : "lax",
    maxAge: Number(process.env.COOKIE_MAX_AGE_DAYS || 1) * 24 * 60 * 60 * 1000,
    path: "/"
  };
}

module.exports = { createToken, cookieOptions };
