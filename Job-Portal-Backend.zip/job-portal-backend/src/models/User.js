const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const educationSchema = new mongoose.Schema({
  institution: { type: String, trim: true, maxlength: 120 },
  qualification: { type: String, trim: true, maxlength: 120 },
  year: { type: Number, min: 1950, max: 2100 }
}, { _id: false });

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, index: true },
  password: { type: String, required: true, minlength: 8, select: false },
  role: { type: String, enum: ["jobseeker", "employer", "admin"], default: "jobseeker", required: true },
  status: { type: String, enum: ["active", "blocked"], default: "active" },
  skills: [{ type: String, trim: true, maxlength: 60 }],
  experience: { type: Number, min: 0, max: 80, default: 0 },
  education: [educationSchema],
  companyName: { type: String, trim: true, maxlength: 120 }
}, { timestamps: true, versionKey: false });

userSchema.pre("save", async function hashPassword() {
  if (!this.isModified("password")) return;
  this.password = await bcrypt.hash(this.password, 12);
});

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

userSchema.methods.toJSON = function toJSON() {
  const result = this.toObject();
  delete result.password;
  delete result.__v;
  return result;
};

module.exports = mongoose.model("User", userSchema);
