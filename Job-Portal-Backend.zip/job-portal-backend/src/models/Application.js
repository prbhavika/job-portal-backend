const mongoose = require("mongoose");

const applicationSchema = new mongoose.Schema({
  job: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true, index: true },
  jobSeeker: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  coverLetter: { type: String, trim: true, maxlength: 4000, default: "" },
  resumeUrl: { type: String, trim: true, maxlength: 500, default: "" },
  status: { type: String, enum: ["submitted", "reviewing", "shortlisted", "rejected", "hired"], default: "submitted" }
}, { timestamps: true, versionKey: false });

applicationSchema.index({ job: 1, jobSeeker: 1 }, { unique: true });

module.exports = mongoose.model("Application", applicationSchema);
