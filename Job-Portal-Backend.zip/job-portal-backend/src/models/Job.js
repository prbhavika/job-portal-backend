const mongoose = require("mongoose");

const jobSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, minlength: 2, maxlength: 120 },
  companyName: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, required: true, trim: true, minlength: 20, maxlength: 8000 },
  location: { type: String, required: true, trim: true, maxlength: 120 },
  employmentType: { type: String, enum: ["full-time", "part-time", "contract", "internship", "temporary"], required: true },
  salaryMin: { type: Number, min: 0, default: null },
  salaryMax: { type: Number, min: 0, default: null },
  requiredSkills: [{ type: String, trim: true, maxlength: 60 }],
  experienceRequired: { type: Number, min: 0, max: 80, default: 0 },
  postedDate: { type: Date, default: Date.now },
  applicationDeadline: { type: Date, required: true },
  status: { type: String, enum: ["open", "closed"], default: "open" },
  employer: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true }
}, { timestamps: true, versionKey: false });

jobSchema.pre("validate", function validateSalary() {
  if (this.salaryMin != null && this.salaryMax != null && this.salaryMin > this.salaryMax) {
    this.invalidate("salaryMin", "Minimum salary cannot exceed maximum salary");
  }
});

module.exports = mongoose.model("Job", jobSchema);
