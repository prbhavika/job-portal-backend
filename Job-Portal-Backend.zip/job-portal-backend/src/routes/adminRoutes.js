const express = require("express");
const { param, body, query } = require("express-validator");
const User = require("../models/User");
const Job = require("../models/Job");
const Application = require("../models/Application");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const { protect, authorize } = require("../middleware/authMiddleware");

const router = express.Router();

router.use(protect, authorize("admin"));

router.get("/users", [query("page").optional().isInt({ min: 1 }), query("limit").optional().isInt({ min: 1, max: 100 })], validate, asyncHandler(async (req, res) => {
  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 20);
  const [users, total] = await Promise.all([
    User.find().sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    User.countDocuments()
  ]);
  res.json({ success: true, page, limit, total, users });
}));

router.get("/users/:id", [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ success: false, message: "User not found" });
  res.json({ success: true, user });
}));

router.patch("/users/:id/status", [param("id").isMongoId(), body("status").isIn(["active", "blocked"])], validate, asyncHandler(async (req, res) => {
  if (String(req.params.id) === String(req.user._id)) {
    return res.status(400).json({ success: false, message: "You cannot change your own account status" });
  }
  const user = await User.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true, runValidators: true });
  if (!user) return res.status(404).json({ success: false, message: "User not found" });
  res.json({ success: true, message: "User status updated", user });
}));

router.delete("/users/:id", [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  if (String(req.params.id) === String(req.user._id)) {
    return res.status(400).json({ success: false, message: "You cannot delete your own account" });
  }
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ success: false, message: "User not found" });
  const ownedJobs = await Job.find({ employer: user._id }).select("_id");
  const ownedJobIds = ownedJobs.map((job) => job._id);
  await Application.deleteMany({ $or: [{ jobSeeker: user._id }, { job: { $in: ownedJobIds } }] });
  await Job.deleteMany({ employer: user._id });
  await user.deleteOne();
  res.json({ success: true, message: "User deleted" });
}));

router.get("/jobs", [query("page").optional().isInt({ min: 1 }), query("limit").optional().isInt({ min: 1, max: 100 })], validate, asyncHandler(async (req, res) => {
  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 20);
  const [jobs, total] = await Promise.all([
    Job.find().populate("employer", "name email companyName").sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit),
    Job.countDocuments()
  ]);
  res.json({ success: true, page, limit, total, jobs });
}));

router.get("/jobs/:id", [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate("employer", "name email companyName");
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  res.json({ success: true, job });
}));

router.delete("/jobs/:id", [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  await Application.deleteMany({ job: job._id });
  await job.deleteOne();
  res.json({ success: true, message: "Job removed" });
}));

router.get("/overview", asyncHandler(async (req, res) => {
  const [users, jobSeekers, employers, jobs, applications] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ role: "jobseeker" }),
    User.countDocuments({ role: "employer" }),
    Job.countDocuments(),
    Application.countDocuments()
  ]);
  res.json({ success: true, totals: { users, jobSeekers, employers, jobs, applications } });
}));

module.exports = router;
