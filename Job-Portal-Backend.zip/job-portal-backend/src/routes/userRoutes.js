const express = require("express");
const { body } = require("express-validator");
const User = require("../models/User");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/profile", protect, (req, res) => {
  res.json({ success: true, user: req.user });
});

router.patch("/profile", protect, [
  body("name").optional().trim().isLength({ min: 2, max: 80 }),
  body("skills").optional().isArray(),
  body("experience").optional().isFloat({ min: 0, max: 80 }),
  body("education").optional().isArray(),
  body("companyName").optional().trim().isLength({ max: 120 })
], validate, asyncHandler(async (req, res) => {
  const allowed = ["name", "skills", "experience", "education", "companyName"];
  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(req.body, key)) req.user[key] = req.body[key];
  }
  await req.user.save();
  res.json({ success: true, message: "Profile updated", user: req.user });
}));

module.exports = router;
