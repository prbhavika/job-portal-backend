const express = require("express");
const { body } = require("express-validator");
const User = require("../models/User");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const { protect } = require("../middleware/authMiddleware");
const { createToken, cookieOptions } = require("../utils/token");

const router = express.Router();

const registerRules = [
  body("name").trim().isLength({ min: 2, max: 80 }),
  body("email").trim().isEmail().normalizeEmail(),
  body("password").isLength({ min: 8 }).withMessage("Password must contain at least 8 characters"),
  body("role").optional().isIn(["jobseeker", "employer"]),
  body("skills").optional().isArray(),
  body("experience").optional().isFloat({ min: 0, max: 80 }),
  body("companyName").optional().trim().isLength({ max: 120 })
];

router.post("/register", registerRules, validate, asyncHandler(async (req, res) => {
  const { name, email, password, role = "jobseeker", skills = [], experience = 0, education = [], companyName = "" } = req.body;
  const existing = await User.findOne({ email });
  if (existing) return res.status(409).json({ success: false, message: "Email is already registered" });

  const user = await User.create({ name, email, password, role, skills, experience, education, companyName });
  const token = createToken(user._id);
  res.cookie("token", token, cookieOptions());
  res.status(201).json({ success: true, message: "Registration successful", user });
}));

router.post("/login", [
  body("email").trim().isEmail().normalizeEmail(),
  body("password").isString().notEmpty()
], validate, asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email }).select("+password");
  if (!user || !(await user.comparePassword(req.body.password))) {
    return res.status(401).json({ success: false, message: "Invalid email or password" });
  }
  if (user.status !== "active") return res.status(403).json({ success: false, message: "Account is blocked" });

  const token = createToken(user._id);
  res.cookie("token", token, cookieOptions());
  res.status(200).json({ success: true, message: "Login successful", user: user.toJSON() });
}));

router.post("/logout", (req, res) => {
  res.clearCookie("token", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: process.env.NODE_ENV === "production" ? "none" : "lax", path: "/" });
  res.status(200).json({ success: true, message: "Logged out successfully" });
});

router.get("/me", protect, (req, res) => {
  res.status(200).json({ success: true, user: req.user });
});

module.exports = router;
