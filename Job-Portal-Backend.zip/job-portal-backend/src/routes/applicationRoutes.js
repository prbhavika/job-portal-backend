const express = require("express");
const { body, param } = require("express-validator");
const Application = require("../models/Application");
const Job = require("../models/Job");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const { protect, authorize } = require("../middleware/authMiddleware");

const router = express.Router();

router.post("/", protect, authorize("jobseeker"), [
  body("jobId").isMongoId(),
  body("coverLetter").optional().trim().isLength({ max: 4000 }),
  body("resumeUrl").optional().trim().isLength({ max: 500 }).isURL()
], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.body.jobId);
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  if (job.status !== "open" || job.applicationDeadline < new Date()) {
    return res.status(400).json({ success: false, message: "This job is no longer accepting applications" });
  }
  const existing = await Application.findOne({ job: job._id, jobSeeker: req.user._id });
  if (existing) return res.status(409).json({ success: false, message: "You have already applied for this job" });

  const application = await Application.create({
    job: job._id,
    jobSeeker: req.user._id,
    coverLetter: req.body.coverLetter || "",
    resumeUrl: req.body.resumeUrl || ""
  });
  res.status(201).json({ success: true, message: "Application submitted", application });
}));

router.get("/mine", protect, authorize("jobseeker"), asyncHandler(async (req, res) => {
  const applications = await Application.find({ jobSeeker: req.user._id })
    .populate({ path: "job", select: "title companyName location employmentType status applicationDeadline employer" })
    .sort({ createdAt: -1 });
  res.json({ success: true, applications });
}));

router.get("/received", protect, authorize("employer"), asyncHandler(async (req, res) => {
  const jobs = await Job.find({ employer: req.user._id }).select("_id");
  const applications = await Application.find({ job: { $in: jobs.map((job) => job._id) } })
    .populate("job", "title companyName")
    .populate("jobSeeker", "name email skills experience education")
    .sort({ createdAt: -1 });
  res.json({ success: true, applications });
}));

router.patch("/:id/status", protect, authorize("employer"), [
  param("id").isMongoId(),
  body("status").isIn(["reviewing", "shortlisted", "rejected", "hired"])
], validate, asyncHandler(async (req, res) => {
  const application = await Application.findById(req.params.id).populate("job");
  if (!application) return res.status(404).json({ success: false, message: "Application not found" });
  if (String(application.job.employer) !== String(req.user._id)) {
    return res.status(403).json({ success: false, message: "You can only manage applications for your own jobs" });
  }
  application.status = req.body.status;
  await application.save();
  res.json({ success: true, message: "Application status updated", application });
}));

module.exports = router;
