const express = require("express");
const { body, param, query } = require("express-validator");
const Job = require("../models/Job");
const Application = require("../models/Application");
const asyncHandler = require("../utils/asyncHandler");
const validate = require("../middleware/validate");
const { protect, authorize } = require("../middleware/authMiddleware");

const router = express.Router();

const jobRules = [
  body("title").trim().isLength({ min: 2, max: 120 }),
  body("companyName").optional().trim().isLength({ min: 2, max: 120 }),
  body("description").trim().isLength({ min: 20, max: 8000 }),
  body("location").trim().isLength({ min: 2, max: 120 }),
  body("employmentType").isIn(["full-time", "part-time", "contract", "internship", "temporary"]),
  body("salaryMin").optional({ nullable: true }).isFloat({ min: 0 }),
  body("salaryMax").optional({ nullable: true }).isFloat({ min: 0 }),
  body("requiredSkills").optional().isArray(),
  body("experienceRequired").optional().isFloat({ min: 0, max: 80 }),
  body("applicationDeadline").isISO8601().toDate(),
  body("status").optional().isIn(["open", "closed"])
];

router.get("/", [
  query("search").optional().trim().isLength({ max: 100 }),
  query("location").optional().trim().isLength({ max: 120 }),
  query("employmentType").optional().isIn(["full-time", "part-time", "contract", "internship", "temporary"]),
  query("page").optional().isInt({ min: 1 }),
  query("limit").optional().isInt({ min: 1, max: 100 })
], validate, asyncHandler(async (req, res) => {
  const filter = { status: "open", applicationDeadline: { $gte: new Date() } };
  if (req.query.search) filter.$or = [
    { title: { $regex: req.query.search, $options: "i" } },
    { companyName: { $regex: req.query.search, $options: "i" } },
    { description: { $regex: req.query.search, $options: "i" } }
  ];
  if (req.query.location) filter.location = { $regex: req.query.location, $options: "i" };
  if (req.query.employmentType) filter.employmentType = req.query.employmentType;

  const page = Number(req.query.page || 1);
  const limit = Number(req.query.limit || 20);
  const [jobs, total] = await Promise.all([
    Job.find(filter).populate("employer", "name companyName").sort({ postedDate: -1 }).skip((page - 1) * limit).limit(limit),
    Job.countDocuments(filter)
  ]);
  res.json({ success: true, page, limit, total, jobs });
}));

router.get("/mine", protect, authorize("employer"), asyncHandler(async (req, res) => {
  const jobs = await Job.find({ employer: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, jobs });
}));

router.get("/:id", [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id).populate("employer", "name companyName");
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  res.json({ success: true, job });
}));

router.post("/", protect, authorize("employer"), jobRules, validate, asyncHandler(async (req, res) => {
  if (new Date(req.body.applicationDeadline) < new Date()) {
    return res.status(400).json({ success: false, message: "Application deadline must be in the future" });
  }
  const job = await Job.create({
    ...req.body,
    companyName: req.body.companyName || req.user.companyName || req.user.name,
    employer: req.user._id
  });
  res.status(201).json({ success: true, message: "Job created", job });
}));

const jobUpdateRules = [
  body("title").optional().trim().isLength({ min: 2, max: 120 }),
  body("companyName").optional().trim().isLength({ min: 2, max: 120 }),
  body("description").optional().trim().isLength({ min: 20, max: 8000 }),
  body("location").optional().trim().isLength({ min: 2, max: 120 }),
  body("employmentType").optional().isIn(["full-time", "part-time", "contract", "internship", "temporary"]),
  body("salaryMin").optional({ nullable: true }).isFloat({ min: 0 }),
  body("salaryMax").optional({ nullable: true }).isFloat({ min: 0 }),
  body("requiredSkills").optional().isArray(),
  body("experienceRequired").optional().isFloat({ min: 0, max: 80 }),
  body("applicationDeadline").optional().isISO8601().toDate(),
  body("status").optional().isIn(["open", "closed"])
];

router.patch("/:id", protect, authorize("employer"), [param("id").isMongoId(), ...jobUpdateRules], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  if (String(job.employer) !== String(req.user._id)) return res.status(403).json({ success: false, message: "You can only update your own jobs" });
  const allowed = ["title", "companyName", "description", "location", "employmentType", "salaryMin", "salaryMax", "requiredSkills", "experienceRequired", "applicationDeadline", "status"];
  for (const key of allowed) {
    if (Object.prototype.hasOwnProperty.call(req.body, key)) job[key] = req.body[key];
  }
  await job.save();
  res.json({ success: true, message: "Job updated", job });
}));

router.delete("/:id", protect, authorize("employer"), [param("id").isMongoId()], validate, asyncHandler(async (req, res) => {
  const job = await Job.findById(req.params.id);
  if (!job) return res.status(404).json({ success: false, message: "Job not found" });
  if (String(job.employer) !== String(req.user._id)) return res.status(403).json({ success: false, message: "You can only delete your own jobs" });
  await Application.deleteMany({ job: job._id });
  await job.deleteOne();
  res.json({ success: true, message: "Job and its applications deleted" });
}));

module.exports = router;
