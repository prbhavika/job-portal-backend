function notFound(req, res, next) {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
}

function errorHandler(error, req, res, next) {
  if (error.code === 11000) {
    return res.status(409).json({ success: false, message: "A record with this value already exists" });
  }
  if (error.name === "CastError") {
    return res.status(400).json({ success: false, message: "Invalid resource ID" });
  }
  if (error.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      message: "Database validation failed",
      errors: Object.values(error.errors).map((item) => item.message)
    });
  }
  const status = error.statusCode || 500;
  res.status(status).json({
    success: false,
    message: status === 500 ? "Internal server error" : error.message
  });
}

module.exports = { notFound, errorHandler };
