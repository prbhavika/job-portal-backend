require("dotenv").config();

const app = require("./src/app");
const connectDB = require("./src/config/db");

const port = Number(process.env.PORT || 5000);

async function start() {
  await connectDB();
  app.listen(port, () => {
    process.stdout.write(`Job Portal API listening on port ${port}\n`);
  });
}

start().catch((error) => {
  process.stderr.write(`${error.message}\n`);
  process.exit(1);
});
